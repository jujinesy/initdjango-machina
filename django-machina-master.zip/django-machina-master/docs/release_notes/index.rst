#############
Release notes
#############



Here are listed the release notes for each version of django-machina.

Django-machina 0.7
------------------

.. toctree::
    :maxdepth: 1

    v0.7

Django-machina 0.6
------------------

.. toctree::
    :maxdepth: 1

    v0.6

Django-machina 0.5
------------------

.. toctree::
    :maxdepth: 1

    v0.5.6
    v0.5.5
    v0.5.4
    v0.5.3
    v0.5.2
    v0.5.1
    v0.5

Django-machina 0.4
------------------

.. toctree::
    :maxdepth: 1

    v0.4

Django-machina 0.3
------------------

.. toctree::
    :maxdepth: 1

    v0.3

Django-machina 0.2
------------------

.. toctree::
    :maxdepth: 1

    v0.2.1
    v0.2
