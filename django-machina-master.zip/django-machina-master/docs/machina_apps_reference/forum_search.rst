############
Forum search
############

The ``forum_search`` application allows to search within forums.

Search indexes
--------------

.. automodule:: machina.apps.forum_search.search_indexes
    :members:
    :show-inheritance:

Views
-----

.. automodule:: machina.apps.forum_search.views
    :members:
    :show-inheritance:
