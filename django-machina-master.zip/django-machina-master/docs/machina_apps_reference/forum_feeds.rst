###########
Forum feeds
###########

The ``forum_feeds`` application allows to get forum topics as RSS feeds.

Feeds
-----

.. automodule:: machina.apps.forum_feeds.feeds
    :members:
    :show-inheritance:
