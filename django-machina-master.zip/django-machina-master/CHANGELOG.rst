Changelog
#########

Please head over to the online documentation in order to browse the release notes for the
django-machina releases: http://django-machina.readthedocs.org/en/stable/release_notes/index.html
