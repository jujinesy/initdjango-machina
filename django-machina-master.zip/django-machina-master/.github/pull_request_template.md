Thank you for contributing to django-machina! A list of simple rules is available on the online
documentation to help you contribute to this project: https://django-machina.readthedocs.org/en/stable/contributing.html.
Please review these guidelines before submitting your pull request!
