# -*- coding: utf-8 -*-

default_app_config = 'machina.apps.forum_permission.registry_config.PermissionRegistryConfig'
