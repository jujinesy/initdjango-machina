# -*- coding: utf-8 -*-

default_app_config = 'machina.apps.forum_conversation.registry_config.ConversationRegistryConfig'
