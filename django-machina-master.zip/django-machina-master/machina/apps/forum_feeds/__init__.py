# -*- coding: utf-8 -*-

default_app_config = 'machina.apps.forum_feeds.registry_config.FeedsRegistryConfig'
