# -*- coding: utf-8 -*-

default_app_config = 'machina.apps.forum_search.registry_config.SearchRegistryConfig'
